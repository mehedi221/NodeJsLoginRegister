module.exports = {
 'connection':{
  'host':'localhost',
  'user':'root',
  'password':'',
 },
 'database':'nodejs_login',
 'user_table':'users',
}